#!/bin/bash

name="PMT-SinglePh - DA";
name2="PMT_SinglePh_DA";
appendix=".tsv"

for i in {1500..1700}
do
  mv "$name""$i""$appendix" "$name2""$i""$appendix"
done
